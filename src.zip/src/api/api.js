import user from './user'

const api = {
    user
}
export default api