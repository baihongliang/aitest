import user from './user'
import cases from './case'

const api = {
    user,
    cases,
}
export default api